# Random Decision Maker (Android)

Простое Android-приложение (WebView + HTML/CSS/JS) — генератор случайных решений с вращающимся колесом.

## Возможности
- Тёмный неоновый интерфейс
- Вращающееся колесо с вариантами
- Несколько сохранённых колёс (наборов вариантов)
- Добавление/удаление вариантов
- Локализация RU/EN
- Звуки (Web Audio API)
- Сохранение данных в `localStorage`

## Сборка APK (на устройстве с AndroidHarness/Termux-подобным окружением)
```sh
sh build-apk.sh
```
Требуются: `aapt2`, `javac`, `jar`, `d8`, `apksigner`, `keytool` и `android.jar` (переменная `ANDROID_JAR` или `$HOME/android-sdk/platforms/...`).

Готовый APK: `RandomDecisionMaker.apk`.
